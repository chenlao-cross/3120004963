package main;

import java.io.*;

public class TxtInOut {
    /**
     * 导入文件
     * @param absPath 文件的绝对路径
     * @return 以字符串的形式返回文件内容
     */
    public static String[] readTxt(String absPath,int num){
        String array[]=new String[num];
        try
        {   int k=0;

            FileReader fr = new FileReader(absPath);
            BufferedReader br = new BufferedReader(fr);
            String s ;
            while((s = br.readLine())!=null) {//读取小学生的答案
                array[k]=s;	k++;
            }br.close();
            fr.close();
            return array;
        }catch(IOException e){
            System.out.println("指定文件不存在");
        }
        return array;

    }



    public static void checkTxt(String absPath,int num,String[] result){

        String youranwers[]=readTxt(absPath,num);
        int rightNum[]=new int[num+2];
        int wrongNum[]=new int[num+2];
        int rightCount=0;
        int wrongCount=0;

        for(int j=0;j<num;j++){
            if(youranwers[j].equals(String.valueOf(j+1)+". "+result[j])) {//验证答案，统计正确和错误的个数

                rightNum[j]=j+1;
                rightCount++;
            }
            else {

                wrongNum[j]=j+1;
                wrongCount++;
            }
        }

        FileWriter fg = null;
        try {
            //反馈正确与错误题目的信息
            File f=new File("Grade.txt");
            fg = new FileWriter(f, false);
        } catch (IOException e) {
            e.printStackTrace();
        }
        PrintWriter pg = new PrintWriter(fg);
        pg.println(" ");
        pg.print("Correct:"+rightCount+"(");
        for (int j = 0; j <= num; j++) {
            if (rightNum[j] != 0) {
                pg.print(rightNum[j] + ",");
            }
        }
        pg.println(")");
        pg.print("Wrong:"+wrongCount+"(");
        for (int j = 0; j <= num; j++) {
            if (wrongNum[j] != 0) {
                pg.print(wrongNum[j] + ",");
            }
        }
        pg.print(")");
        pg.flush();
        try {
            fg.flush();
            pg.close();
            fg.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    /**
     * 导出为txt文件
     * @param absPath 绝对路径
     */
    public  static  void writeTxt(String[] str,String absPath){
        File file = new File(absPath);
        FileWriter fileWriter=null;
        try{
            fileWriter=new FileWriter(file,false);
            for(int i=0;i<str.length;i++){
                fileWriter.write((i+1)+". ");
                fileWriter.write(str[i]);
                fileWriter.write("\r\n");
            }
            fileWriter.close();
        }catch (IOException e){
            e.printStackTrace();
        }

    }


}
