package main;

import java.util.Scanner;

public class Main {

    public static int range;//数字范围
    public static int num;//表达式数量
    public static String[] expression;
    public static String[] result;



    public static void main(String[] args){

        createMenu();

        for(int i=0;i<num;i++){
            String[] str=Expression.expressionCreat(range);
            if(str[0]=="false"){
                i--;
                continue;
            }
            expression[i]=str[0];
            result[i]=str[1];
        }
        TxtInOut.writeTxt(expression,args[0]);
        TxtInOut.writeTxt(result,args[1]);

        TxtInOut.checkTxt(args[1],num,result);
    }

/*
    public static void menu(String[] args){
        Scanner sc= new Scanner(System.in);
        System.out.println("请选择功能（1或2）：\r\n");
        System.out.println("1.生成题目\r\n");
        System.out.println("2.校验答案\r\n");
        String input=sc.next();
        switch(input)
        {
            case "1":createMenu();break;
            case "2":checkMenu(args);break;
            default:System.out.println("输入错误，请重新输入：\r\n"); menu(args); break;

        }


    }*/

    /*
    public static void checkMenu(String[] args){
        System.out.println("已生成校验文档");
        String ansStu=TxtInOut.readTxt(args[2]);
        String ans=TxtInOut.readTxt(args[3]);


        System.exit(0);

    }*/

    public static void createMenu(){
        Scanner sc= new Scanner(System.in);
        System.out.println("请输入产生几以内的数字：");
        range=sc.nextInt();
        System.out.println("请输入产生多少个运算表达式：");
        num=sc.nextInt();
        expression=new String[num];
        result=new String[num];


    }



}
